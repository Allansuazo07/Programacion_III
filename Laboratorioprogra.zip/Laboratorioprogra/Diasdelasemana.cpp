#include <iostream>
#include <vector>
#include <string>
using namespace std;

class DiasSemana {
private:
    vector<string> dias;

public:
    DiasSemana() {
        dias = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado","Domingo"};
    }

    void mostrarDias() {
        for (const auto& dia : dias) {
            cout << dia << endl;
        }
    }

    int posicionDia(string dia) {
        for (int i = 0; i < dias.size(); i++) {
            if (dias[i] == dia) {
                return i + 1;
            }
        }
        return -1; // Si no encuentra el día
    }
};

int main() {
    DiasSemana semana;
    semana.mostrarDias();

    string dia;
    cout << "Introduce el día que deseas buscar : "<<endl;
    cin >> dia;

    int posicion = semana.posicionDia(dia);
    if (posicion != -1) {
        cout << "La posición de " << dia << " es : " << posicion << endl;
    } else {
        cout << "Día no encontrado." << endl;
    }

    return 0;
}